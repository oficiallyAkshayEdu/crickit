from distutils.core import setup

setup(
    name='crickit',
    version='0.0.10b-dev',
    packages=['crickit'],
    url="https://github.com/oficiallyAkshayEdu/crickit",
    license='MITa',
    author='Akshay Agrawal',
    author_email='',
    description='Text based Cricket Simulator in Python'
)
